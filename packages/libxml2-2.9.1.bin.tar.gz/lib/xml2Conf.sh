#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/Users/hnw/Development/arm-android-18-app/libxml2-2.9.1/lib"
XML2_LIBS="-lxml2 -L/Users/hnw/Development/arm-android-18-app/zlib-1.2.8/lib -lz  -L/Users/hnw/Development/arm-android-18-app/libiconv-1.14/lib -lm "
XML2_INCLUDEDIR="-I/Users/hnw/Development/arm-android-18-app/libxml2-2.9.1/include/libxml2 -I/Users/hnw/Development/arm-android-18-app/libiconv-1.14/include"
MODULE_VERSION="xml2-2.9.1"

